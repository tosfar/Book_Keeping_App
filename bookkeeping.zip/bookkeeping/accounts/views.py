# accounts/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Customer, Transaction
from .forms import CustomerForm, TransactionForm

# View for listing customers and their current balances
def customer_list(request):
    customers = Customer.objects.all()
    return render(request, 'accounts/customer_list.html', {'customers': customers})

# View for adding a new customer
def add_customer(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('customer_list')
    else:
        form = CustomerForm()
    return render(request, 'accounts/customer_form.html', {'form': form})

# View for adding a transaction
def add_transaction(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('customer_list')
    else:
        form = TransactionForm()
    return render(request, 'accounts/transaction_form.html', {'form': form})

# View for customer details and transaction history
def customer_detail(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    transactions = customer.transaction_set.all()
    return render(request, 'accounts/customer_detail.html', {'customer': customer, 'transactions': transactions})
