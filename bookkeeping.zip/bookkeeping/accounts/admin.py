# accounts/admin.py
from django.contrib import admin
from .models import Customer, Transaction

admin.site.register(Customer)
admin.site.register(Transaction)
