# bookkeeping/urls.py
from django.urls import path
from accounts import views

urlpatterns = [
    path('', views.customer_list, name='customer_list'),
    path('customer/add/', views.add_customer, name='add_customer'),
    path('transaction/add/', views.add_transaction, name='add_transaction'),
    path('customer/<int:customer_id>/', views.customer_detail, name='customer_detail'),
]
