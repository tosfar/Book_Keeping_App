# accounts/forms.py
from django import forms
from .models import Customer, Transaction

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['name', 'initial_balance']

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['customer', 'transaction_type', 'amount']
