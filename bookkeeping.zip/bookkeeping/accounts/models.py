# accounts/models.py
from django.db import models

class Customer(models.Model):
    name = models.CharField(max_length=100)
    initial_balance = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name

    @property
    def current_balance(self):
        # Calculate current balance by summing debits and subtracting credits
        balance = self.initial_balance
        transactions = self.transaction_set.all()  # Fetch all transactions related to this customer
        for transaction in transactions:
            if transaction.transaction_type == 'debit':
                balance += transaction.amount
            elif transaction.transaction_type == 'credit':
                balance -= transaction.amount
        return balance


class Transaction(models.Model):
    TRANSACTION_TYPE_CHOICES = [
        ('debit', 'Debit'),
        ('credit', 'Credit'),
    ]
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=6, choices=TRANSACTION_TYPE_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.transaction_type} - {self.amount} - {self.customer.name}"
